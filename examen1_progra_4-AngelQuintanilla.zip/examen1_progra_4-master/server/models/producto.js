const mongoose = require('mongoose');

let Schema = mongoose.Schema;

//Definir el esquema para el modelo Producto (Valor 5 puntos)
const nombre = require(`Cafe`)=>{
required = true
}
let precio : (`5`)=> {
    required = true   
}
let creado_en : (`Angel`)=>{
    
}


module.exports = mongoose.model('Producto', usuarioSchema);